package com.desarrollo.herbalife.ui.viewmodel;

/**
 * Created by oswaldo on 30/01/16.
 */
public interface IRecyclerView {
    public void onItemReciclerView(int position);
    public void onWebReciclerView();
    public void onFavoritePublication();
    public void onFacebookReciclerView();
    public void onTwitterReciclerView();
    public void onWhatsappReciclerView();

}
